const mongoose = require('mongoose')
const Schema = mongoose.Schema;

//Schema
const postSchema = new Schema({
    title: {
        type: String,
        required: true
    },
    rating: {
        type: Number,
        required: true
    },
    review: {
        type: String,
        required: true
    },
    like: {
        type: String,
        required: false
    },
    dislike: {
        type: String,
        required: false
    },
    user: {
        type: String,
        required: false
    }
}, { timestamps: true });

//Model
const Post = mongoose.model('Post', postSchema) //Automatically searches for 'posts' collections in mongodb 

module.exports = Post