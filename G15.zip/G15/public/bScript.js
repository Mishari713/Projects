//Search function
function myFunction() {
    var input, filter, ul, h5, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("carddeck");
    li = ul.getElementsByClassName("col-4");
    for (i = 0; i < li.length; i++) {
      h5 = li[i].getElementsByTagName("h5")[0];
      txtValue = h5.textContent || h5.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = "";
      } else {
        li[i].style.display = "none";
      }
    }
  }

  //button function - increase
function increase() {
    var value = $(this).parent().find('[data-value]').val();
    if (value >= 0) {
      value++;
      $(this).parent().find('[data-value]').val(value);
    }
  }
  
  //button function - changing the value
  function valueChange() {
    var value = $(this).val();
    if (value == undefined || isNaN(value) == true || value <= 0) {
      $(this).val(0);
    }
  }
  
  //button function
$(function () {
    $('[data-decrease]').click(decrease);
    $('[data-increase]').click(increase);
    $('[data-value]').change(valueChange);
  });
  
  //button function - decrease
  function decrease() {
    var value = $(this).parent().find('[data-value]').val();
    if (value > 0) {
      value--;
      $(this).parent().find('[data-value]').val(value);
    }
  }