//Imports
const express = require('express');
const mongoose = require('mongoose')
const User = require('./models/user')
const Post = require('./models/post')


var gUser;

// const dbURI= "mongodb+srv://Mishari:P319Owner@cluster0.fm7umxm.mongodb.net/test";
// // express app
// const app = express();

// mongoose.connect(dbURI, {useNewUrlParser:true, useUnifiedTopology:true}).then((result) =>{
// //If connected to DB
// console.log("Connected to mongoDB");
// //listen for requests 
// app.listen(3000);
// }).catch((err) => {
// console.log(err);
// });

//Temporary data - items
// var login = [
//   {quantity: 0, price: 69.99, name: 'Elden Ring', img: 'eldenring.jpg'},
//   {quantity: 0, price: 49.99, name: 'God Of War', img: 'GOW.jpg'},
//   {quantity: 0, price: 24.99, name: 'Mortal Kombat 11', img: 'MK11.jpg'},
//   {quantity: 0, price: 64.99, name: 'Modern Warfer', img: 'MW1.jpg'},
//   {quantity: 0, price: 34.99, name: 'The Witcher 3', img: 'Witcher.jpg'},
//   {quantity: 0, price: 34.99, name: 'Sekiro', img: 'Sekiro.jpg'}
// ];

// register view engine
app.set('view engine', 'ejs');
// app.set('views', 'myviews');

//Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

//Routing
app.get('/', (req, res) => {
  res.redirect('/Areview')
});

app.get('/Areview/', (req, res) => {
  Post.find().sort({createdAt: -1}).then((result) => {
    res.render('./Areview/home', { title: 'Home', posts: result});
    }).catch((err) => {
    console.log(err)
    });
});

app.get('/login', (req, res) => {
  res.render('./Areview/login', { title: 'Log in'});
});

app.get('/post', (req, res) => {
  res.render('./Areview/post', { title: 'Post'});
});

app.get('/registration', (req, res) => {
  res.render('./Areview/registration', { title: 'Registration'});
});

app.get('/home', (req, res) => {
  res.redirect('/');
});


app.post('/register', (req, res) => {
  const user = new User ({ 
    name: req.body.name, 
    email: req.body.email,
    password: req.body.password, 
    loggedIn: false, 
    }).save().then((result) => { 
    }).catch((err) => { 
    console.log(err)
    });

    res.redirect('./login')
});

app.post('/login', (req, res) => {
  User.findOneAndUpdate({email : req.body.email, password : req.body.password}, { $set: { loggedIn: true } },).then((result) => {
    console.log("Result:" + result)
    if(!result){
      console.log("wrong pass or email but in")
      res.render('./Areview/login', {err: "password is wrong"});
    }
    else{
      gUser = result
      console.log(gUser)
      console.log("right pass and email")
      res.redirect('/');
    }
  }).catch((err) => {
    console.log(err)
  })
  });

  app.post('/post', (req, res) => {
    const post = new Post ({ 
      title: req.body.title, 
      rating: req.body.rating,
      review: req.body.review, 
      }).save().then((result) => { 
      }).catch((err) => { 
      console.log(err)
      });
  
      res.redirect('/')
  });

// 404 page 
app.use((req, res) => {
  res.status(404).render('404', { title: '404' });
});

// function calculate(){
//   amount.subtotal = 0;
//   amount.tax = 0;
//   amount.total = 0;
//   var temp;
//   for(i= 0; i< Scart.length; i++){
//     amount.subtotal += parseFloat(Scart[i].price * Scart[i].quantity); 
//   }
//   amount.subtotal = amount.subtotal.toFixed(2);
//   amount.tax = (amount.subtotal * 0.08).toFixed(2);
//   amount.total = parseFloat(amount.subtotal) + parseFloat(amount.tax);
//   amount.total = amount.total.toFixed(2);
// }